﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TurAgenstvo.Models;

namespace TurAgenstvo.Pages
{
    /// <summary>
    /// Логика взаимодействия для LoginPage.xaml
    /// </summary>
    public partial class LoginPage : Page
    {
        public LoginPage()
        {
            InitializeComponent();
        }
        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            App.Current.Shutdown();

        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            string login = txtUser.Text;
            string password = txtPass.Password;
            var loggedUser = App.DB.Sotrudnik.FirstOrDefault(x => x.Login == login && x.Password == password);
            var loggedKlient = App.DB.Klient.FirstOrDefault(x => x.Login == login && x.Password == password);
            App.LoggerUser = loggedUser;
            App.LoggerKlient = loggedKlient;

            if (loggedKlient == null && loggedUser == null)
            {
                MessageBox.Show("Не верный логин или пароль");
                return;
            }

            if (loggedKlient != null && loggedKlient.idRole == 2)
            {
                NavigationService.Navigate(new KlientPage());
                MessageBox.Show("Добро пожаловать " + loggedKlient.FIO + "!");
            }

            if (loggedUser != null && loggedUser.idRole == 1)
            {
                NavigationService.Navigate(new AdminstrationPage());
                MessageBox.Show("Добро пожаловать " + loggedUser.FIO + "!");
            }
        }
    }
 }        
    

