﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TurAgenstvo.Models;

namespace TurAgenstvo.Pages
{
    /// <summary>
    /// Логика взаимодействия для TuriPage.xaml
    /// </summary>
    public partial class TuriPage : Page
    {
        public TuriPage()
        {
            InitializeComponent();
            DGApp.ItemsSource = App.LoggerUser.Applicatio;
           
        }

        private void btnAddAplication_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddZaprosi(new Applicatio()));
        }

        private void btnRedactionApplication_Click(object sender, RoutedEventArgs e)
        {
            var selectedApplicatio = DGApp.SelectedItem as Applicatio;
            if (selectedApplicatio == null)
            {
                MessageBox.Show("Выберите заявку которую надо изменить");
                return;
            }
            NavigationService.Navigate(new AddZaprosi(selectedApplicatio));
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            DGApp.ItemsSource = App.LoggerUser.Applicatio;
        }

        private void DGApp_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            Applicatio selectedItem = DGApp.SelectedItem as Applicatio ;
            if (selectedItem != null)
            {
                DataContext = selectedItem;
                
            }
        }

    }
}
