﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TurAgenstvo.Models;

namespace TurAgenstvo.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddTurPage.xaml
    /// </summary>
    public partial class AddTurPage : Page
    {
        Turi contextTuri;
        public AddTurPage(Turi turi)
        {
            InitializeComponent();
            CBOtel.ItemsSource = App.DB.Otel.ToList();
            CBTypeOfFood.ItemsSource = App.DB.TypeOfFood.ToList();
            CBСountry.ItemsSource = App.DB.Country.ToList();
            contextTuri = turi;
            DataContext = contextTuri;
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        private void btnAddTuri_Click(object sender, RoutedEventArgs e)
        {
            string errorMessage = "";
            if (contextTuri.ArrivalDate < DateTime.Now)
                errorMessage += "Дата заказа не может быть меньше или равно сегоднящнего дня\n ";
            if (contextTuri.Information.Length > 10000)
                errorMessage += "Слишком длинный информационный текст\n";
            if (string.IsNullOrWhiteSpace(contextTuri.Information))
                errorMessage += "Заполните строку информация\n";
            if (string.IsNullOrWhiteSpace(contextTuri.Name))
                errorMessage += "Заполните строку название тура\n";
            if (!string.IsNullOrWhiteSpace(errorMessage))
            {
                MessageBox.Show(errorMessage);
                return;
            }
            App.DB.SaveChanges();
            if (contextTuri.id == 0)
                App.DB.Turi.Add(contextTuri);
            App.DB.SaveChanges();
            NavigationService.GoBack();
            {
                MessageBox.Show("Заявка успешно добавлена");
            }
        }
    }
}
