﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TurAgenstvo.Pages
{
    /// <summary>
    /// Логика взаимодействия для AdminstrationPage.xaml
    /// </summary>
    public partial class AdminstrationPage : Page
    {
        public AdminstrationPage()
        {
            InitializeComponent();
            labelUsername.Content = App.LoggerUser.FIO;
        }

        private void btnProgramma_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnTuri_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new TuriNewPage());
        }

        private void btnOtel_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnTuristi_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new TuristiPage());
        }

        private void btnYslugi_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            App.Current.Shutdown();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        private void btnApplication_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new TuriPage());
        }
    }
}
