﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TurAgenstvo.Models;

namespace TurAgenstvo.Pages
{
    /// 
    /// Логика взаимодействия для TuriNewPage.xaml
    /// 
    public partial class TuriNewPage : Page
    {
        public TuriNewPage()
        {
            InitializeComponent();
            var otels = App.DB.Otel.ToList();
            otels.Insert(0, new Otel() { Name = "Все" });
            CBOtel.ItemsSource = otels;
            var countrys = App.DB.Country.ToList();
            countrys.Insert(0, new Country() { Name = "Все" });
            CBCountry.ItemsSource = countrys;
            DGTuri.ItemsSource = App.DB.Turi.ToList();
            Refresh();
        }

        private void btnPoisk_Click(object sender, RoutedEventArgs e)
        {
            Refresh();
        }

        private void Refresh()
        {
            var filtred = App.DB.Turi.ToList();
            var selectedDate = DTDateArival.SelectedDate;
            var selectedOtel = CBOtel.SelectedItem as Otel;
            var selectedCountry = CBCountry.SelectedItem as Country;

            if (selectedCountry != null && selectedCountry.Name != "Все")
                filtred = filtred.Where(x => x.idCountry == selectedCountry.id).ToList();
            if (selectedDate != null)
                filtred = filtred.Where(x => x.ArrivalDate == selectedDate).ToList();
            if (selectedOtel != null && selectedOtel.Name != "Все")
                filtred = filtred.Where(x => x.idOtel == selectedOtel.id).ToList();

            DGTuri.ItemsSource = filtred;
        }

        private void btnAddTur_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddTurPage(new Turi()));
        }

        private void btnRedactionTur_Click(object sender, RoutedEventArgs e)
        {
            var selectedTuri = DGTuri.SelectedItem as Turi;
            if (selectedTuri == null)
            {
                MessageBox.Show("Выберите тур");
                return;
            }
            NavigationService.Navigate(new AddTurPage(selectedTuri));
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            DGTuri.ItemsSource = App.DB.Turi.ToList();
        }

        private void TBPrice_TextChanged(object sender, TextChangedEventArgs e)
        {
            var filtred = App.DB.Turi.ToList();
            var searchText = TBPrice.Text.ToLower();

            if (!string.IsNullOrWhiteSpace(searchText))
                filtred = filtred.Where(x => x.Name.ToString().Contains(searchText)).ToList();
            DGTuri.ItemsSource = filtred.ToList();
        }

        private void btnSbros_Click(object sender, RoutedEventArgs e)
        {
            TBPrice.Text = "";
            CBCountry.SelectedIndex = 0;
            CBOtel.SelectedIndex = 0;
            DTDateArival.SelectedDate = null;
            Refresh(); 
        }
    }
}


