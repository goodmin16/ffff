﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TurAgenstvo.Models
{
    public partial class Otel
    {
        public string ServiceList
        {
            get
            {
                string serviceList = "";
                foreach (var otelServices in OtelServices)
                {
                    serviceList += otelServices.Services.Name + ", ";
                }
                return serviceList;
            }
        }
    }
}
